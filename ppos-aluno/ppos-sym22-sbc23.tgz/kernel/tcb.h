// PingPongOS - PingPong Operating System
// © Prof. Carlos A. Maziero, DINF UFPR
// Versão 2.1 -- 06/2026

// Este arquivo PODE/DEVE ser alterado.

// Descritor de tarefas (TCB - Task Control Block).

// GRR20221224 Seijiro Yanagiya Midzuno
// GRR20232333 Sofia Barbosa Candiotto

#ifndef __PPOS_TCB__
#define __PPOS_TCB__

#include "ctx.h"
#include "lib/queue.h"

#define STACK_SIZE 16 * 1024

// Status possíveis da tarefa
typedef enum {
    NEW,
    READY,
    EXEC,
    SUSP,
    TERM,
} Task_status;

// Task Control Block (TCB), infos sobre uma tarefa
struct task_t
{
    int id;                 // identificador da tarefa
    char *name;             // nome da tarefa
    struct ctx_t context;   // contexto da tarefa
    Task_status status;     // pronta, executando, ...
    int exit_code;          // saída
    struct task_t* parent;  // pai da tarefa
    
    int priod;               // prioridade dinamica da tarefa
    int prioe;               // prioridade estática da tarefa
    
    int quantum;             // ticks restantes no quantum atual
    int birth_time;          // "horário" de nascimento
    int act_time;            // "horario" da última ativação
    int exec_time;           // tempo de execução
    int acts;                // ativações

    struct queue_t *wait_queue; // fila de tarefas que aguardam minha conclusão
    int wait_code;             // código de saída retornado ao waiter

    unsigned int wake_time;    // instante em que a tarefa deve acordar
    // ...                  // demais informações, a completar
};

extern struct task_t task_kernel; 
extern struct task_t* task_atual; // ponteiro para a a task atual sendo executada

extern int id_i; // id da última task criada

#endif
